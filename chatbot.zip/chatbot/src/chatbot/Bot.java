package chatbot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
public class Bot extends JFrame {

    JTextArea Chatarea =  new JTextArea();
	JTextField Chatbox =  new JTextField();
		
	public Bot() {
	
		JFrame frame1 = new JFrame();

		frame1.setSize(500,500);
		frame1.setLayout(null);
		frame1.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame1.setVisible(true);
		frame1.setResizable(false);
		frame1.setTitle("CHATBOT");
	    frame1.add(Chatbox);
	    frame1.add(Chatarea);
	    
	    Chatarea.setSize(500,500);
	    Chatarea.setLocation(5,5);
	    Chatbox.setSize(500,30);
	    Chatbox.setLocation(5,350);
	    
	    Chatarea.setText("BOT-> hello" + "\n");
	   Chatbox.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String gtext = Chatbox.getText();
			
			Chatarea.append("you->" + gtext + "\n");
			Chatbox.setText("");
			int x=1;
			for(x=1;x<20;x++) {
				if(x==1) {
					if(gtext.contains("hello")||gtext.contains("hi")||gtext.contains("hey")) {
						bot("How are you ");
					}
							else {
								int rand =(int)(Math.random()*3+1);
								if(rand==1) {
									bot(" I dont understand you");
								}
								else if(rand==2) {
									bot("come again please");
								}
								else if(rand==3) {
									bot("Sorry , I dont know that");
								}         				
							}

					}
				
					else if (x==2)  {
						if(gtext.contains("Good")||gtext.contains("Fine")||gtext.contains("I am good")) {
							bot("good to hear that, Do you have any plans for weekend ");
						}
								else {
									int rand =(int)(Math.random()*3+1);
									if(rand==1) {
										bot(" I dont understand you");
									}
									else if(rand==2) {
										bot("come again please");
									}
									else if(rand==3) {
										bot("Sorry , I dont know that");
									}         				
								}

						
					}
					else if (x==3)  {
						if(gtext.contains("yes")||gtext.contains("yeah")) {
							bot("nice , what are your plans? ");
						}
								else {
									bot ("Do you want to go out for dinner?");
								}
											
										}
					else if (x==4)  {
						if(gtext.contains("yes")||gtext.contains("yeah")) {
							bot("what time are you free ");
						}
								else {
									bot("are you free net weekend? ");         				
								}
						
					}
					else if (x==5)  {
						if(gtext.contains("yes")||gtext.contains("yeah")) {
							bot("do you want to grab dinner then ");
						}
								else {
								bot("When are you free");      				
								}
						
					}
					else if (x==6)  {
						if(gtext.contains("never")||gtext.contains("I am not free")) {
							bot(" lets meet virtually? ");
						}
								else {
								bot("sounds great, do you wanna watch a movie");      				
								}
						
					}
					else if (x==7)  {
						if(gtext.contains("yes")||gtext.contains("yeah")) {
							bot("what kind of movie would you like to watch");
						}
								else {
								bot("do you want to go for lunch then?");      				
								}
						
					}
					else if (x==8)  {
						if(gtext.contains("yes")||gtext.contains("yeah")) {
							bot("ohk , i have tickets for blabla on sunday at 9, would you like to join me ");
						}
								else {
								bot("ohk sure");      				
								}
						
					}
					
			}
			
		}	
			});
				   
		}
			
			
		
				
				
			
				
	public void bot(String str) {
		Chatbox.setText("");
		Chatarea.append("Bot-> " + str + "\n");    
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
new Bot ();

	}

}
