import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

abstract class ChatBotTest extends JFrame implements ActionListener{
	

public ChatBotTest(String title) {
		super();
		// TODO Auto-generated constructor stub
	}

	@Test
	void testChatBot() {
		
		
		
	}
//
	@Test
	void testActionPerformed() {
		
		
	}
//
	@Test
	void testBot() {
		//fail("Not yet implemented");
		//area.append("Bot : " +"\n");
	}

	@Test
	public void testMain() {
	//	fail("Not yet implemented");
		ChatBot cb=new ChatBot("Chat Bot");
		cb.setSize(800,605);
		cb.setLocation(50,50);
		
		
	}

//	@Test
//	void testRemoveComponent() {
//		fail("Not yet implemented");
//	}

}
